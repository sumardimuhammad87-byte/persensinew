import { Student, Rombel, UserAccount, SchoolConfig, AttendanceRecord, AttendanceToken, AttendanceStatus, AttendanceMethod, UserRole, Teacher, Subject, ScheduleItem, TeacherAttendanceRecord, TeacherAttendanceStatus, DayOfWeek } from '../types';
import { INITIAL_SCHOOL_CONFIG, INITIAL_ROMBEL, INITIAL_STUDENTS, INITIAL_USERS, INITIAL_TEACHERS, INITIAL_SUBJECTS, INITIAL_SCHEDULES, generateInitialAttendance } from '../data/initialData';
import { syncRombelOfficersWithUserAccounts } from './officerSync';
import { syncTeachersAndWalasWithUserAccounts } from './teacherWalasSync';
export { syncTeachersAndWalasWithUserAccounts };

const KEYS = {
  CONFIG: 'absensi_school_config_v1',
  ROMBEL: 'absensi_rombel_v1',
  STUDENTS: 'absensi_students_v1',
  USERS: 'absensi_users_v1',
  ATTENDANCE: 'absensi_records_v1',
  TOKENS: 'absensi_tokens_v1',
  CURRENT_USER: 'absensi_current_user_v1',
  TEACHERS: 'absensi_teachers_v1',
  SUBJECTS: 'absensi_subjects_v1',
  SCHEDULES: 'absensi_schedules_v1',
  TEACHER_ATTENDANCE: 'absensi_teacher_records_v1',
};

export function getTodayDateStr(): string {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function getCurrentTimeStr(): string {
  const d = new Date();
  const h = String(d.getHours()).padStart(2, '0');
  const m = String(d.getMinutes()).padStart(2, '0');
  const s = String(d.getSeconds()).padStart(2, '0');
  return `${h}:${m}:${s}`;
}

// Safe Storage Wrapper to prevent QuotaExceededError or unhandled storage crashes
function safeSetItem(key: string, value: string): boolean {
  try {
    localStorage.setItem(key, value);
    return true;
  } catch (err: any) {
    console.warn(`[Storage Warning] Gagal menyimpan key "${key}":`, err?.message || err);

    // Try cleaning expired tokens or redundant session data to free up space, never corrupting user data
    try {
      localStorage.removeItem(KEYS.CURRENT_USER);
      localStorage.removeItem(KEYS.TOKENS);
      localStorage.setItem(key, value);
      return true;
    } catch {
      return false;
    }
  }
}

// 1. School Config
export function loadSchoolConfig(): SchoolConfig {
  try {
    const raw = localStorage.getItem(KEYS.CONFIG);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && parsed.namaSekolah) {
        // Automatically migrate if saved with previous default name
        if (
          parsed.namaSekolah === 'SMK KESEHATAN BHAKTI HUSADA' ||
          parsed.namaSekolah.toLowerCase().includes('bhakti husada')
        ) {
          parsed.namaSekolah = 'SMK Bakti Putra Mandiri';
          if (parsed.email && parsed.email.includes('husada')) {
            parsed.email = 'info@smkbaktiputramandiri.sch.id';
          }
          if (parsed.website && parsed.website.includes('husada')) {
            parsed.website = 'www.smkbaktiputramandiri.sch.id';
          }
          saveSchoolConfig(parsed);
        }
        return parsed;
      }
    }
  } catch (e) {
    console.error('[Storage] Gagal memuat SchoolConfig:', e);
  }
  return INITIAL_SCHOOL_CONFIG;
}

export function saveSchoolConfig(config: SchoolConfig): void {
  safeSetItem(KEYS.CONFIG, JSON.stringify(config));
}

// 2. Rombel
export function loadRombelList(): Rombel[] {
  try {
    const raw = localStorage.getItem(KEYS.ROMBEL);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch (e) {
    console.error('[Storage] Gagal memuat RombelList:', e);
  }
  return INITIAL_ROMBEL;
}

export function saveRombelList(list: Rombel[]): void {
  safeSetItem(KEYS.ROMBEL, JSON.stringify(list));
}

// 3. Students
export function loadStudentList(): Student[] {
  try {
    const raw = localStorage.getItem(KEYS.STUDENTS);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch (e) {
    console.error('[Storage] Gagal memuat StudentList:', e);
  }
  return INITIAL_STUDENTS;
}

export function saveStudentList(list: Student[]): void {
  safeSetItem(KEYS.STUDENTS, JSON.stringify(list));
}

// 4. Users
export function loadUserList(): UserAccount[] {
  let list = INITIAL_USERS;
  try {
    const raw = localStorage.getItem(KEYS.USERS);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        list = parsed;
      }
    }
  } catch (e) {
    console.error('[Storage] Gagal memuat UserList:', e);
  }

  // Ensure single account consolidation for students & officers, and Walas & Teachers
  try {
    const rombels = loadRombelList();
    const students = loadStudentList();
    const teachers = loadTeacherList();
    const officerSynced = syncRombelOfficersWithUserAccounts(rombels, students, list);
    const teacherWalasSynced = syncTeachersAndWalasWithUserAccounts(teachers, rombels, officerSynced.updatedUsers);
    const allStudentsSynced = generateMassStudentAccounts(students, teacherWalasSynced.updatedUsers, rombels);
    return allStudentsSynced.updatedUsers;
  } catch (err) {
    console.warn('[Storage] Officer/Teacher consolidation sync error:', err);
    return list;
  }
}

export function saveUserList(list: UserAccount[]): void {
  safeSetItem(KEYS.USERS, JSON.stringify(list));
}

// Helper: Ensure a student has an active UserAccount for instant login
// Automatically checks if student is assigned as Ketua Kelas or Sekretaris in any rombel
export function ensureStudentUserAccount(
  student: Student,
  existingUsers: UserAccount[],
  rombels?: Rombel[]
): { updatedUsers: UserAccount[]; createdUser: UserAccount } {
  const cleanNipd = student.nipd.trim();
  const currentRombels = rombels || loadRombelList();

  // Check if student holds an officer position in their rombel
  const studentRombel = currentRombels.find((r) => r.id === student.rombelId);
  const isKetua = studentRombel?.ketuaKelasNipd === cleanNipd;
  const isSekretaris = studentRombel?.sekretarisNipd === cleanNipd;

  let assignedRole: UserRole = 'siswa';
  let assignedJabatan = 'Siswa';
  if (isKetua) {
    assignedRole = 'ketua_kelas';
    assignedJabatan = `Ketua Kelas (${studentRombel?.nama || ''})`;
  } else if (isSekretaris) {
    assignedRole = 'sekretaris';
    assignedJabatan = `Sekretaris Kelas (${studentRombel?.nama || ''})`;
  }

  const existingIdx = existingUsers.findIndex(
    (u) => (u.nipd && u.nipd.trim() === cleanNipd) || u.username === cleanNipd
  );

  if (existingIdx >= 0) {
    // Update existing user info while preserving their single unified account
    const updated = [...existingUsers];
    const prev = updated[existingIdx];
    updated[existingIdx] = {
      ...prev,
      nama: student.nama,
      nisn: student.nisn || prev.nisn,
      foto: student.foto !== undefined ? student.foto : prev.foto,
      role: isKetua ? 'ketua_kelas' : isSekretaris ? 'sekretaris' : prev.role === 'admin' || prev.role === 'guru' ? prev.role : 'siswa',
      rombelId: student.rombelId,
      jabatan: assignedJabatan,
      statusAktif: student.statusAktif ?? true,
    };
    saveUserList(updated);
    return { updatedUsers: updated, createdUser: updated[existingIdx] };
  }

  // Create brand new login account for this student (1 single account)
  const newUser: UserAccount = {
    id: `USR-STD-${cleanNipd.replace(/[^a-zA-Z0-9]/g, '')}`,
    email: `${cleanNipd.replace(/[^a-zA-Z0-9]/g, '')}@siswa.sch.id`,
    username: cleanNipd,
    nama: student.nama,
    role: assignedRole,
    password: '123', // Default PIN for student / officer
    nipd: cleanNipd,
    nisn: student.nisn,
    rombelId: student.rombelId,
    jabatan: assignedJabatan,
    foto: student.foto,
    statusAktif: true,
  };

  const updated = [newUser, ...existingUsers];
  saveUserList(updated);
  return { updatedUsers: updated, createdUser: newUser };
}

// Helper: Remove student user account if student is deleted
export function removeStudentUserAccount(
  nipd: string,
  existingUsers: UserAccount[]
): UserAccount[] {
  const clean = nipd.trim();
  const filtered = existingUsers.filter(
    (u) => !(u.role === 'siswa' && (u.nipd === clean || u.username === clean))
  );
  saveUserList(filtered);
  return filtered;
}

// Mass generate student accounts from existing student records
export function generateMassStudentAccounts(
  students: Student[],
  existingUsers: UserAccount[],
  rombels?: Rombel[]
): { updatedUsers: UserAccount[]; countAdded: number; createdUsers: UserAccount[] } {
  let countAdded = 0;
  const createdUsers: UserAccount[] = [];
  const userMap = new Map<string, UserAccount>();
  const userNipdSet = new Set<string>();
  const userNisnSet = new Set<string>();
  const currentRombels = rombels || loadRombelList();

  existingUsers.forEach((u) => {
    userMap.set(u.id, u);
    if (u.nipd) {
      userNipdSet.add(u.nipd.trim().toLowerCase());
      userNipdSet.add(u.nipd.replace(/[^a-zA-Z0-9]/g, '').toLowerCase());
    }
    if (u.nisn) {
      userNisnSet.add(u.nisn.trim().toLowerCase());
      userNisnSet.add(u.nisn.replace(/\D/g, ''));
    }
    if (u.username) {
      userNipdSet.add(u.username.trim().toLowerCase());
      userNipdSet.add(u.username.replace(/[^a-zA-Z0-9]/g, '').toLowerCase());
    }
  });

  students.forEach((std) => {
    const cleanNipd = std.nipd.trim();
    const cleanNipdLower = cleanNipd.toLowerCase();
    const cleanNipdAlpha = cleanNipd.replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
    const cleanNisn = std.nisn?.trim().toLowerCase();
    const cleanNisnDigits = cleanNisn ? cleanNisn.replace(/\D/g, '') : '';

    const hasAccount =
      userNipdSet.has(cleanNipdLower) ||
      userNipdSet.has(cleanNipdAlpha) ||
      (cleanNisn && userNisnSet.has(cleanNisn)) ||
      (cleanNisnDigits && userNisnSet.has(cleanNisnDigits));

    if (!hasAccount) {
      countAdded++;
      const studentRombel = currentRombels.find((r) => r.id === std.rombelId);
      const isKetua = studentRombel?.ketuaKelasNipd === cleanNipd;
      const isSekretaris = studentRombel?.sekretarisNipd === cleanNipd;

      let assignedRole: UserRole = 'siswa';
      let assignedJabatan = 'Siswa';
      if (isKetua) {
        assignedRole = 'ketua_kelas';
        assignedJabatan = `Ketua Kelas (${studentRombel?.nama || ''})`;
      } else if (isSekretaris) {
        assignedRole = 'sekretaris';
        assignedJabatan = `Sekretaris Kelas (${studentRombel?.nama || ''})`;
      }

      const accountId = `USR-STD-${cleanNipd.replace(/[^a-zA-Z0-9]/g, '')}`;
      const newUser: UserAccount = {
        id: accountId,
        email: `${cleanNipd.replace(/[^a-zA-Z0-9]/g, '')}@siswa.sch.id`,
        username: std.nisn || cleanNipd,
        nama: std.nama,
        role: assignedRole,
        password: '123', // default PIN / password for student
        nipd: cleanNipd,
        nisn: std.nisn,
        rombelId: std.rombelId,
        jabatan: assignedJabatan,
        foto: std.foto,
        statusAktif: std.statusAktif !== false,
      };
      userMap.set(accountId, newUser);
      createdUsers.push(newUser);
      userNipdSet.add(cleanNipdLower);
      userNipdSet.add(cleanNipdAlpha);
      if (cleanNisn) userNisnSet.add(cleanNisn);
      if (cleanNisnDigits) userNisnSet.add(cleanNisnDigits);
    }
  });

  const updatedUsers = Array.from(userMap.values());
  saveUserList(updatedUsers);
  return { updatedUsers, countAdded, createdUsers };
}

// Deterministic attendance record ID generator for cross-device consistency
export function generateAttendanceRecordId(nipd: string, tanggal: string): string {
  const cleanNipd = nipd.trim().replace(/[^a-zA-Z0-9]/g, '_');
  return `ATT_${tanggal}_${cleanNipd}`;
}

// 5. Attendance
export function loadAttendanceRecords(): AttendanceRecord[] {
  try {
    const raw = localStorage.getItem(KEYS.ATTENDANCE);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        // Keep all valid records across any dates, only filtering corrupted entries
        const cleanList = parsed.filter((r) => {
          if (!r || !r.nipd || !r.tanggal || !r.status) return false;
          return true;
        });

        if (cleanList.length !== parsed.length) {
          saveAttendanceRecords(cleanList);
        }
        return cleanList;
      }
    }
  } catch (e) {
    console.error(e);
  }
  return [];
}

export function saveAttendanceRecords(list: AttendanceRecord[]): void {
  safeSetItem(KEYS.ATTENDANCE, JSON.stringify(list));
}

// 6. Active Tokens
export function loadTokens(): AttendanceToken[] {
  try {
    const raw = localStorage.getItem(KEYS.TOKENS);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (e) {
    console.error(e);
  }
  return [
    {
      id: 'TOK-DEMO-1',
      token: 'ABS-7429',
      rombelId: 'ALL',
      createdBy: 'Guru Piket',
      createdRole: 'guru',
      createdAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 60 * 60 * 1000).toISOString(),
      isActive: true,
    }
  ];
}

export function saveTokens(tokens: AttendanceToken[]): void {
  safeSetItem(KEYS.TOKENS, JSON.stringify(tokens));
}

// 7. Session User
export function loadCurrentUser(): UserAccount | null {
  try {
    const raw = localStorage.getItem(KEYS.CURRENT_USER);
    if (raw) {
      if (raw === 'null' || raw === 'undefined') return null;
      return JSON.parse(raw);
    }
  } catch (e) {
    console.error(e);
  }
  // Return null so login page is displayed if not authenticated
  return null;
}

export function saveCurrentUser(user: UserAccount | null): void {
  if (!user) {
    try {
      localStorage.removeItem(KEYS.CURRENT_USER);
    } catch {}
  } else {
    safeSetItem(KEYS.CURRENT_USER, JSON.stringify(user));
  }
}

// Helper: Calculate attendance percentage
export function calculateAttendanceRate(hadirCount: number, effectiveDays: number): number {
  if (effectiveDays <= 0) return 100;
  const rate = (hadirCount / effectiveDays) * 100;
  return Math.min(100, Math.max(0, Math.round(rate * 10) / 10));
}

// Record or update attendance for a student on a specific date (defaults to today)
export function recordAttendance(
  nipd: string,
  rombelId: string,
  status: AttendanceStatus,
  metode: AttendanceMethod,
  recordedByRole: UserRole,
  recordedByName: string,
  tokenUsed?: string,
  keterangan?: string,
  targetDate?: string,
  targetTime?: string
): AttendanceRecord[] {
  const currentRecords = loadAttendanceRecords();
  const dateStr = targetDate || getTodayDateStr();
  const timeStr = targetTime || getCurrentTimeStr();
  const deterministicId = generateAttendanceRecordId(nipd, dateStr);

  const existingIndex = currentRecords.findIndex(
    (r) => (r.nipd === nipd && r.tanggal === dateStr) || r.id === deterministicId
  );

  const updatedRecord: AttendanceRecord = {
    id: deterministicId,
    nipd,
    rombelId,
    tanggal: dateStr,
    waktu: timeStr,
    status,
    metode,
    recordedByRole,
    recordedByName,
    tokenUsed,
    keterangan,
  };

  let nextRecords: AttendanceRecord[];
  if (existingIndex >= 0) {
    nextRecords = [...currentRecords];
    nextRecords[existingIndex] = updatedRecord;
  } else {
    nextRecords = [updatedRecord, ...currentRecords];
  }

  saveAttendanceRecords(nextRecords);
  return nextRecords;
}

// Save or overwrite a single attendance record directly (e.g. from Admin CRUD modal)
export function saveAttendanceRecordDirect(record: AttendanceRecord): AttendanceRecord[] {
  const currentRecords = loadAttendanceRecords();
  const deterministicId = record.id || generateAttendanceRecordId(record.nipd, record.tanggal);
  const finalRecord = { ...record, id: deterministicId };
  // Filter out any existing record with the same ID, or same student and date (to prevent duplicates if date was modified)
  const filtered = currentRecords.filter(
    (r) => r.id !== deterministicId && !(r.nipd === record.nipd && r.tanggal === record.tanggal)
  );
  const nextRecords = [finalRecord, ...filtered];
  saveAttendanceRecords(nextRecords);
  return nextRecords;
}

// Delete an attendance record by ID (e.g. from Admin CRUD)
export function deleteAttendanceRecord(recordId: string): AttendanceRecord[] {
  const currentRecords = loadAttendanceRecords();
  const filtered = currentRecords.filter((r) => r.id !== recordId);
  saveAttendanceRecords(filtered);
  return filtered;
}

// Delete attendance record by student NIPD and date (Resets student to 'Belum Absen')
export function deleteAttendanceByStudentAndDate(nipd: string, tanggal: string): AttendanceRecord[] {
  const currentRecords = loadAttendanceRecords();
  const deterministicId = generateAttendanceRecordId(nipd, tanggal);
  const filtered = currentRecords.filter(
    (r) => !(r.nipd === nipd && r.tanggal === tanggal) && r.id !== deterministicId
  );
  saveAttendanceRecords(filtered);
  return filtered;
}

// Delete multiple attendance records in batch
export function deleteAttendanceRecordsBatch(recordIds: string[]): AttendanceRecord[] {
  const idSet = new Set(recordIds);
  const currentRecords = loadAttendanceRecords();
  const filtered = currentRecords.filter((r) => !idSet.has(r.id));
  saveAttendanceRecords(filtered);
  return filtered;
}

// Student Self Check-in with Token validation
export function validateTokenAndCheckIn(
  tokenCode: string,
  student: Student,
  user: UserAccount
): { success: boolean; message: string } {
  const tokens = loadTokens();
  const cleanCode = tokenCode.trim().toUpperCase();

  const matchedToken = tokens.find(
    (t) => t.token.toUpperCase() === cleanCode && t.isActive
  );

  if (!matchedToken) {
    return { success: false, message: 'Kode token tidak ditemukan atau sudah dinonaktifkan!' };
  }

  const now = new Date().getTime();
  const expireTime = new Date(matchedToken.expiresAt).getTime();
  if (now > expireTime) {
    return { success: false, message: 'Masa berlaku token telah habis/kedaluwarsa!' };
  }

  // Check target class
  if (matchedToken.rombelId !== 'ALL' && matchedToken.rombelId !== student.rombelId) {
    return { success: false, message: 'Token ini khusus untuk kelas lain, bukan rombel Anda!' };
  }

  // Record presence
  recordAttendance(
    student.nipd,
    student.rombelId,
    'hadir',
    'token',
    'siswa',
    user.nama,
    matchedToken.token,
    `Presensi mandiri via token ${matchedToken.token}`
  );

  return {
    success: true,
    message: `Presensi berhasil! Anda tercatat HADIR hari ini pukul ${getCurrentTimeStr()}.`,
  };
}

// Reset all storage to pristine seed state
export function resetAllData(): void {
  try {
    localStorage.removeItem(KEYS.CONFIG);
    localStorage.removeItem(KEYS.ROMBEL);
    localStorage.removeItem(KEYS.STUDENTS);
    localStorage.removeItem(KEYS.USERS);
    localStorage.removeItem(KEYS.ATTENDANCE);
    localStorage.removeItem(KEYS.TOKENS);
    localStorage.removeItem(KEYS.CURRENT_USER);
    localStorage.removeItem(KEYS.TEACHERS);
    localStorage.removeItem(KEYS.SUBJECTS);
    localStorage.removeItem(KEYS.SCHEDULES);
  } catch (e) {
    console.error(e);
  }
}

// 8. Teachers (Data Guru)
export function loadTeacherList(): Teacher[] {
  try {
    const raw = localStorage.getItem(KEYS.TEACHERS);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch (e) {
    console.error('[Storage] Gagal memuat TeacherList:', e);
  }
  return INITIAL_TEACHERS;
}

export function saveTeacherList(list: Teacher[]): void {
  safeSetItem(KEYS.TEACHERS, JSON.stringify(list));
}

// Helper: Ensure a Teacher has an active UserAccount (consolidated 1 account for Walas & Guru)
export function ensureTeacherUserAccount(
  teacher: Teacher,
  existingUsers: UserAccount[]
): { updatedUsers: UserAccount[]; createdUser: UserAccount } {
  const rombels = loadRombelList();
  const { updatedUsers } = syncTeachersAndWalasWithUserAccounts([teacher], rombels, existingUsers);
  saveUserList(updatedUsers);

  const matched =
    updatedUsers.find((u) => u.teacherId === teacher.id) ||
    updatedUsers.find((u) => u.id === `USR-GUR-${teacher.id}`) ||
    updatedUsers[0];

  return { updatedUsers, createdUser: matched };
}

// Mass Sync / Ensure all Teachers and Walas have exactly 1 consolidated UserAccount
export function syncAllTeacherAccounts(
  teachers: Teacher[],
  existingUsers: UserAccount[],
  rombels?: Rombel[]
): { updatedUsers: UserAccount[]; countAdded: number; countUpdated: number; countSynced: number } {
  const currentRombels = rombels || loadRombelList();
  const { updatedUsers, countCreated, countConsolidated } = syncTeachersAndWalasWithUserAccounts(
    teachers,
    currentRombels,
    existingUsers
  );
  saveUserList(updatedUsers);

  return {
    updatedUsers,
    countAdded: countCreated,
    countUpdated: countConsolidated,
    countSynced: countCreated + countConsolidated,
  };
}

// Remove teacher login account
export function removeTeacherUserAccount(
  email?: string,
  nip?: string,
  existingUsers: UserAccount[] = []
): UserAccount[] {
  const cleanEmail = email?.toLowerCase().trim();
  const cleanNip = nip?.replace(/\s+/g, '');
  const filtered = existingUsers.filter((u) => {
    if (u.role === 'admin') return true;
    if (cleanEmail && u.email && u.email.toLowerCase().trim() === cleanEmail) return false;
    if (cleanNip && u.username && u.username === cleanNip) return false;
    return true;
  });
  saveUserList(filtered);
  return filtered;
}

// 9. Subjects (Mata Pelajaran)
export function loadSubjectList(): Subject[] {
  try {
    const raw = localStorage.getItem(KEYS.SUBJECTS);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch (e) {
    console.error('[Storage] Gagal memuat SubjectList:', e);
  }
  return INITIAL_SUBJECTS;
}

export function saveSubjectList(list: Subject[]): void {
  safeSetItem(KEYS.SUBJECTS, JSON.stringify(list));
}

// Automatically synchronize Mata Pelajaran defined in Teacher entities into master Subjects
export function syncSubjectsWithTeachers(
  teachers: Teacher[],
  existingSubjects: Subject[]
): { updatedSubjects: Subject[]; newSubjects: Subject[] } {
  const subjectsMap = new Map<string, Subject>();
  existingSubjects.forEach((s) => {
    if (s.nama) subjectsMap.set(s.nama.toLowerCase().trim(), s);
    if (s.id) subjectsMap.set(s.id.toLowerCase().trim(), s);
  });

  const newSubjects: Subject[] = [];
  teachers.forEach((t) => {
    (t.mataPelajaran || []).forEach((m) => {
      const trimmed = (m || '').trim();
      if (!trimmed) return;
      if (!subjectsMap.has(trimmed.toLowerCase())) {
        const cleanCode = trimmed.replace(/[^a-zA-Z0-9]/g, '').slice(0, 4).toUpperCase() || 'MAPEL';
        const hash = Math.abs(
          trimmed.split('').reduce((a, b) => ((a << 5) - a) + b.charCodeAt(0), 0)
        ).toString(36).toUpperCase();
        const newSubj: Subject = {
          id: `MAPEL-GUR-${hash}`,
          kode: `${cleanCode}-01`,
          nama: trimmed,
          kelompok: 'Peminatan Kejuruan (C)',
          tingkat: 'Semua',
          jurusan: 'Semua',
          jamPerMinggu: 2,
          statusAktif: true,
        };
        subjectsMap.set(trimmed.toLowerCase(), newSubj);
        newSubjects.push(newSubj);
      }
    });
  });

  const updatedSubjects = [...existingSubjects, ...newSubjects];
  if (newSubjects.length > 0) {
    saveSubjectList(updatedSubjects);
  }
  return { updatedSubjects, newSubjects };
}

// 10. Schedules (Jadwal Pelajaran)
export function loadScheduleList(): ScheduleItem[] {
  try {
    const raw = localStorage.getItem(KEYS.SCHEDULES);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch (e) {
    console.error('[Storage] Gagal memuat ScheduleList:', e);
  }
  return INITIAL_SCHEDULES;
}

export function saveScheduleList(list: ScheduleItem[]): void {
  safeSetItem(KEYS.SCHEDULES, JSON.stringify(list));
}

// 11. Presensi Guru (Teacher Attendance)
export function loadTeacherAttendanceRecords(): TeacherAttendanceRecord[] {
  try {
    const raw = localStorage.getItem(KEYS.TEACHER_ATTENDANCE);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (e) {
    console.error('[Storage] Gagal memuat TeacherAttendance:', e);
  }
  return [];
}

export function saveTeacherAttendanceRecords(records: TeacherAttendanceRecord[]): void {
  safeSetItem(KEYS.TEACHER_ATTENDANCE, JSON.stringify(records));
}

export function recordTeacherAttendance(
  record: TeacherAttendanceRecord,
  existingRecords?: TeacherAttendanceRecord[]
): TeacherAttendanceRecord[] {
  const currentList =
    existingRecords && existingRecords.length > 0 ? existingRecords : loadTeacherAttendanceRecords();
  const cleanId = record.id || `TATT-${record.tanggal}-${record.teacherId}`;
  const recordWithId = { ...record, id: cleanId };

  // Check if existing record for this teacher on this date
  const idx = currentList.findIndex(
    (r) => r.id === cleanId || (r.teacherId === record.teacherId && r.tanggal === record.tanggal)
  );

  let updated: TeacherAttendanceRecord[];
  if (idx >= 0) {
    updated = [...currentList];
    updated[idx] = { ...updated[idx], ...recordWithId };
  } else {
    updated = [recordWithId, ...currentList];
  }

  saveTeacherAttendanceRecords(updated);
  return updated;
}

export function deleteTeacherAttendanceRecord(
  id: string,
  existingRecords?: TeacherAttendanceRecord[]
): TeacherAttendanceRecord[] {
  const currentList =
    existingRecords && existingRecords.length > 0 ? existingRecords : loadTeacherAttendanceRecords();
  const filtered = currentList.filter((r) => r.id !== id);
  saveTeacherAttendanceRecords(filtered);
  return filtered;
}

// Helper to determine day name in Indonesian (Senin, Selasa, etc.)
export function getIndonesianDayName(dateInput?: string | Date): DayOfWeek {
  const d = dateInput
    ? typeof dateInput === 'string'
      ? new Date(dateInput.includes('T') ? dateInput : `${dateInput}T00:00:00`)
      : dateInput
    : new Date();

  const dayIndex = d.getDay(); // 0 = Minggu, 1 = Senin, ...
  const dayMap: Record<number, DayOfWeek> = {
    1: 'Senin',
    2: 'Selasa',
    3: 'Rabu',
    4: 'Kamis',
    5: 'Jumat',
    6: 'Sabtu',
  };
  return dayMap[dayIndex] || 'Senin';
}

// Helper to check whether a teacher has teaching hours on a specific day
export function checkTeacherTeachingHours(
  teacherId: string,
  allSchedules: ScheduleItem[],
  targetDateOrDay?: string | DayOfWeek
): {
  hasTeachingHours: boolean;
  countSessions: number;
  totalJamPelajaran: number;
  dayName: DayOfWeek;
  schedulesToday: ScheduleItem[];
  allTeacherSchedules: ScheduleItem[];
  nextSchedule?: { day: DayOfWeek; schedule: ScheduleItem } | null;
} {
  const allTeacherSchedules = allSchedules.filter((s) => s.teacherId === teacherId);

  let dayName: DayOfWeek;
  if (
    targetDateOrDay === 'Senin' ||
    targetDateOrDay === 'Selasa' ||
    targetDateOrDay === 'Rabu' ||
    targetDateOrDay === 'Kamis' ||
    targetDateOrDay === 'Jumat' ||
    targetDateOrDay === 'Sabtu'
  ) {
    dayName = targetDateOrDay;
  } else {
    dayName = getIndonesianDayName(targetDateOrDay);
  }

  const schedulesToday = allTeacherSchedules.filter((s) => s.hari === dayName);

  // Sort by jamMulai ascending
  schedulesToday.sort((a, b) => (a.jamMulai || '').localeCompare(b.jamMulai || ''));

  // Calculate total JP
  const totalJamPelajaran = schedulesToday.reduce((acc, curr) => acc + (curr.jumlahJam || 2), 0);

  // Find next teaching schedule if today has no teaching hours
  let nextSchedule: { day: DayOfWeek; schedule: ScheduleItem } | null = null;
  if (schedulesToday.length === 0 && allTeacherSchedules.length > 0) {
    const daysOrder: DayOfWeek[] = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    const currentIdx = daysOrder.indexOf(dayName);
    for (let i = 1; i <= 6; i++) {
      const nextDayIdx = (currentIdx + i) % 6;
      const nextDayName = daysOrder[nextDayIdx];
      const found = allTeacherSchedules.find((s) => s.hari === nextDayName);
      if (found) {
        nextSchedule = { day: nextDayName, schedule: found };
        break;
      }
    }
  }

  return {
    hasTeachingHours: schedulesToday.length > 0,
    countSessions: schedulesToday.length,
    totalJamPelajaran,
    dayName,
    schedulesToday,
    allTeacherSchedules,
    nextSchedule,
  };
}

export interface FullBackupPayload {
  version: string;
  exportedAt: string;
  schoolConfig: SchoolConfig;
  rombels: Rombel[];
  students: Student[];
  users: UserAccount[];
  attendanceRecords: AttendanceRecord[];
  tokens: AttendanceToken[];
  teachers?: Teacher[];
  subjects?: Subject[];
  schedules?: ScheduleItem[];
  teacherAttendanceRecords?: TeacherAttendanceRecord[];
}

// Export entire system data to portable JSON backup
export function exportFullDatabaseBackup(): string {
  const payload: FullBackupPayload = {
    version: '1.2',
    exportedAt: new Date().toISOString(),
    schoolConfig: loadSchoolConfig(),
    rombels: loadRombelList(),
    students: loadStudentList(),
    users: loadUserList(),
    attendanceRecords: loadAttendanceRecords(),
    tokens: loadTokens(),
    teachers: loadTeacherList(),
    subjects: loadSubjectList(),
    schedules: loadScheduleList(),
    teacherAttendanceRecords: loadTeacherAttendanceRecords(),
  };
  return JSON.stringify(payload, null, 2);
}

// Restore entire system data from JSON backup
export function importFullDatabaseBackup(rawJson: string): {
  success: boolean;
  message: string;
  data?: FullBackupPayload;
} {
  try {
    const parsed = JSON.parse(rawJson) as FullBackupPayload;
    if (!parsed || !parsed.schoolConfig || !Array.isArray(parsed.students)) {
      return {
        success: false,
        message: 'Format berkas cadangan JSON tidak valid atau rusak.',
      };
    }

    if (parsed.schoolConfig) saveSchoolConfig(parsed.schoolConfig);
    if (Array.isArray(parsed.rombels)) saveRombelList(parsed.rombels);
    if (Array.isArray(parsed.students)) saveStudentList(parsed.students);
    if (Array.isArray(parsed.users)) saveUserList(parsed.users);
    if (Array.isArray(parsed.attendanceRecords)) saveAttendanceRecords(parsed.attendanceRecords);
    if (Array.isArray(parsed.tokens)) saveTokens(parsed.tokens);
    if (Array.isArray(parsed.teachers)) saveTeacherList(parsed.teachers);
    if (Array.isArray(parsed.subjects)) saveSubjectList(parsed.subjects);
    if (Array.isArray(parsed.schedules)) saveScheduleList(parsed.schedules);
    if (Array.isArray(parsed.teacherAttendanceRecords)) saveTeacherAttendanceRecords(parsed.teacherAttendanceRecords);

    return {
      success: true,
      message: `Cadangan berhasil dipulihkan! ${parsed.students.length} siswa, ${parsed.teachers?.length || 0} guru, dan ${parsed.users?.length || 0} akun pengguna telah disinkronkan.`,
      data: parsed,
    };
  } catch (e: any) {
    return {
      success: false,
      message: `Gagal membaca berkas: ${e?.message || 'Format JSON tidak valid'}`,
    };
  }
}
