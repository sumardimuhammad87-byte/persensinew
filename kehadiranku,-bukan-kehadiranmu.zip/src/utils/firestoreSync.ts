import {
  collection,
  doc,
  setDoc,
  deleteDoc,
  onSnapshot,
  getDocs,
  writeBatch,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './firebase';
import {
  Student,
  Rombel,
  UserAccount,
  Teacher,
  Subject,
  ScheduleItem,
  AttendanceRecord,
  AttendanceToken,
  SchoolConfig,
  TeacherAttendanceRecord,
} from '../types';
import {
  saveStudentList,
  saveRombelList,
  saveUserList,
  saveTeacherList,
  saveSubjectList,
  saveScheduleList,
  saveAttendanceRecords,
  loadAttendanceRecords,
  saveTokens,
  saveSchoolConfig,
  saveTeacherAttendanceRecords,
  FullBackupPayload,
} from './storage';

// Safe doc id helper (escapes slashes and special characters if any)
export function sanitizeDocId(id: string): string {
  if (!id) return `doc_${Date.now()}`;
  return encodeURIComponent(String(id).trim()).replace(/%/g, '_');
}

export interface FirestoreDataCallbacks {
  onStudentsLoaded?: (data: Student[]) => void;
  onRombelsLoaded?: (data: Rombel[]) => void;
  onUsersLoaded?: (data: UserAccount[]) => void;
  onTeachersLoaded?: (data: Teacher[]) => void;
  onSubjectsLoaded?: (data: Subject[]) => void;
  onSchedulesLoaded?: (data: ScheduleItem[]) => void;
  onAttendanceLoaded?: (data: AttendanceRecord[]) => void;
  onTokensLoaded?: (data: AttendanceToken[]) => void;
  onSchoolConfigLoaded?: (data: SchoolConfig) => void;
  onTeacherAttendanceLoaded?: (data: TeacherAttendanceRecord[]) => void;
  onInitialSyncComplete?: () => void;
}

// Clean payload helper to ensure no 'undefined' properties are sent to Firestore (which causes Firestore to reject writes)
export function cleanForFirestore<T>(data: T): T {
  if (data === null || data === undefined) return data;
  return JSON.parse(JSON.stringify(data));
}

// Reusable batch chunking helper to write up to 400 docs per transaction safely
export async function firestoreSaveBatchChunked<T>(
  collectionName: string,
  items: T[],
  getId: (item: T) => string
): Promise<void> {
  if (!items || items.length === 0) return;
  const CHUNK_SIZE = 400;
  for (let i = 0; i < items.length; i += CHUNK_SIZE) {
    const chunk = items.slice(i, i + CHUNK_SIZE);
    const batch = writeBatch(db);
    chunk.forEach((item) => {
      const docId = sanitizeDocId(getId(item));
      const cleaned = cleanForFirestore(item);
      batch.set(doc(db, collectionName, docId), cleaned, { merge: true });
    });
    try {
      await batch.commit();
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, collectionName);
    }
  }
}


// Subscribe to all collections for real-time multi-device synchronization
export function subscribeToFirestore(
  callbacks: FirestoreDataCallbacks,
  initialFallbacks: {
    students: Student[];
    rombels: Rombel[];
    users: UserAccount[];
    teachers: Teacher[];
    subjects: Subject[];
    schedules: ScheduleItem[];
    attendance: AttendanceRecord[];
    tokens: AttendanceToken[];
    schoolConfig: SchoolConfig;
    teacherAttendance?: TeacherAttendanceRecord[];
  }
) {
  const unsubscribers: (() => void)[] = [];
  let pendingInitialListeners = 10;

  const notifyInitialLoaded = () => {
    pendingInitialListeners--;
    if (pendingInitialListeners <= 0) {
      callbacks.onInitialSyncComplete?.();
    }
  };

  // 1. School Config
  try {
    const unsub = onSnapshot(
      doc(db, 'school_config', 'main'),
      (docSnap) => {
        if (docSnap.exists()) {
          const cfg = docSnap.data() as SchoolConfig;
          if (
            cfg.namaSekolah === 'SMK KESEHATAN BHAKTI HUSADA' ||
            cfg.namaSekolah?.toLowerCase().includes('bhakti husada')
          ) {
            cfg.namaSekolah = 'SMK Bakti Putra Mandiri';
            if (cfg.email && cfg.email.includes('husada')) {
              cfg.email = 'info@smkbaktiputramandiri.sch.id';
            }
            if (cfg.website && cfg.website.includes('husada')) {
              cfg.website = 'www.smkbaktiputramandiri.sch.id';
            }
            setDoc(doc(db, 'school_config', 'main'), cfg, { merge: true }).catch(() => {});
          }
          callbacks.onSchoolConfigLoaded?.(cfg);
          saveSchoolConfig(cfg);
        } else {
          // Only seed if missing completely in Firestore
          setDoc(doc(db, 'school_config', 'main'), initialFallbacks.schoolConfig, { merge: true }).catch(
            (e) => handleFirestoreError(e, OperationType.WRITE, 'school_config/main')
          );
        }
        notifyInitialLoaded();
      },
      (err) => {
        handleFirestoreError(err, OperationType.GET, 'school_config/main');
        notifyInitialLoaded();
      }
    );
    unsubscribers.push(unsub);
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, 'school_config/main');
    notifyInitialLoaded();
  }

  // 2. Rombels
  try {
    const unsub = onSnapshot(
      collection(db, 'rombels'),
      (snap) => {
        if (snap.empty && initialFallbacks.rombels && initialFallbacks.rombels.length > 0) {
          firestoreSaveBatchChunked('rombels', initialFallbacks.rombels, (r) => r.id);
          callbacks.onRombelsLoaded?.(initialFallbacks.rombels);
          saveRombelList(initialFallbacks.rombels);
        } else {
          const items = snap.docs.map((d) => d.data() as Rombel);
          callbacks.onRombelsLoaded?.(items);
          saveRombelList(items);
        }
        notifyInitialLoaded();
      },
      (err) => {
        handleFirestoreError(err, OperationType.GET, 'rombels');
        notifyInitialLoaded();
      }
    );
    unsubscribers.push(unsub);
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, 'rombels');
    notifyInitialLoaded();
  }

  // 3. Students
  try {
    let hasMergedInitialStudents = false;
    const unsub = onSnapshot(
      collection(db, 'students'),
      (snap) => {
        if (snap.empty && initialFallbacks.students && initialFallbacks.students.length > 0) {
          firestoreSaveBatchChunked('students', initialFallbacks.students, (s) => s.nipd);
          callbacks.onStudentsLoaded?.(initialFallbacks.students);
          saveStudentList(initialFallbacks.students);
        } else {
          const items = snap.docs.map((d) => d.data() as Student);
          let finalStudents = items;
          // Merge local students if any were added offline before cloud synced
          if (!hasMergedInitialStudents && initialFallbacks.students && initialFallbacks.students.length > 0) {
            hasMergedInitialStudents = true;
            const missingInCloud = initialFallbacks.students.filter(
              (ls) => ls && ls.nipd && !items.some((cs) => cs.nipd === ls.nipd)
            );
            if (missingInCloud.length > 0) {
              firestoreSaveBatchChunked('students', missingInCloud, (s) => s.nipd);
              finalStudents = [...items, ...missingInCloud];
            }
          }
          callbacks.onStudentsLoaded?.(finalStudents);
          saveStudentList(finalStudents);
        }
        notifyInitialLoaded();
      },
      (err) => {
        handleFirestoreError(err, OperationType.GET, 'students');
        notifyInitialLoaded();
      }
    );
    unsubscribers.push(unsub);
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, 'students');
    notifyInitialLoaded();
  }

  // 4. Users
  try {
    let hasMergedInitialUsers = false;
    const unsub = onSnapshot(
      collection(db, 'users'),
      (snap) => {
        if (snap.empty && initialFallbacks.users && initialFallbacks.users.length > 0) {
          firestoreSaveBatchChunked('users', initialFallbacks.users, (u) => u.id);
          callbacks.onUsersLoaded?.(initialFallbacks.users);
          saveUserList(initialFallbacks.users);
        } else {
          const items = snap.docs.map((d) => d.data() as UserAccount);
          let finalUsers = items;
          // Merge local users if any were created offline before cloud synced
          if (!hasMergedInitialUsers && initialFallbacks.users && initialFallbacks.users.length > 0) {
            hasMergedInitialUsers = true;
            const missingInCloud = initialFallbacks.users.filter(
              (lu) => lu && lu.id && !items.some((cu) => cu.id === lu.id || (cu.username && cu.username === lu.username))
            );
            if (missingInCloud.length > 0) {
              firestoreSaveBatchChunked('users', missingInCloud, (u) => u.id);
              finalUsers = [...items, ...missingInCloud];
            }
          }
          callbacks.onUsersLoaded?.(finalUsers);
          saveUserList(finalUsers);
        }
        notifyInitialLoaded();
      },
      (err) => {
        handleFirestoreError(err, OperationType.GET, 'users');
        notifyInitialLoaded();
      }
    );
    unsubscribers.push(unsub);
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, 'users');
    notifyInitialLoaded();
  }

  // 5. Teachers (Preserves deletions across all devices)
  try {
    let hasMergedInitialTeachers = false;
    const unsub = onSnapshot(
      collection(db, 'teachers'),
      (snap) => {
        if (snap.empty && initialFallbacks.teachers && initialFallbacks.teachers.length > 0) {
          firestoreSaveBatchChunked('teachers', initialFallbacks.teachers, (t) => t.id);
          callbacks.onTeachersLoaded?.(initialFallbacks.teachers);
          saveTeacherList(initialFallbacks.teachers);
        } else {
          const items = snap.docs.map((d) => d.data() as Teacher);
          let finalTeachers = items;
          // Merge local teachers if any were created offline
          if (!hasMergedInitialTeachers && initialFallbacks.teachers && initialFallbacks.teachers.length > 0) {
            hasMergedInitialTeachers = true;
            const missingInCloud = initialFallbacks.teachers.filter(
              (lt) => lt && lt.id && !items.some((ct) => ct.id === lt.id || (ct.nip && ct.nip === lt.nip))
            );
            if (missingInCloud.length > 0) {
              firestoreSaveBatchChunked('teachers', missingInCloud, (t) => t.id);
              finalTeachers = [...items, ...missingInCloud];
            }
          }
          callbacks.onTeachersLoaded?.(finalTeachers);
          saveTeacherList(finalTeachers);
        }
        notifyInitialLoaded();
      },
      (err) => {
        handleFirestoreError(err, OperationType.GET, 'teachers');
        notifyInitialLoaded();
      }
    );
    unsubscribers.push(unsub);
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, 'teachers');
    notifyInitialLoaded();
  }

  // 6. Subjects
  try {
    const unsub = onSnapshot(
      collection(db, 'subjects'),
      (snap) => {
        if (snap.empty && initialFallbacks.subjects && initialFallbacks.subjects.length > 0) {
          firestoreSaveBatchChunked('subjects', initialFallbacks.subjects, (s) => s.id);
          callbacks.onSubjectsLoaded?.(initialFallbacks.subjects);
          saveSubjectList(initialFallbacks.subjects);
        } else {
          const items = snap.docs.map((d) => d.data() as Subject);
          callbacks.onSubjectsLoaded?.(items);
          saveSubjectList(items);
        }
        notifyInitialLoaded();
      },
      (err) => {
        handleFirestoreError(err, OperationType.GET, 'subjects');
        notifyInitialLoaded();
      }
    );
    unsubscribers.push(unsub);
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, 'subjects');
    notifyInitialLoaded();
  }

  // 7. Schedules
  try {
    const unsub = onSnapshot(
      collection(db, 'schedules'),
      (snap) => {
        if (snap.empty && initialFallbacks.schedules && initialFallbacks.schedules.length > 0) {
          firestoreSaveBatchChunked('schedules', initialFallbacks.schedules, (s) => s.id);
          callbacks.onSchedulesLoaded?.(initialFallbacks.schedules);
          saveScheduleList(initialFallbacks.schedules);
        } else {
          const items = snap.docs.map((d) => d.data() as ScheduleItem);
          callbacks.onSchedulesLoaded?.(items);
          saveScheduleList(items);
        }
        notifyInitialLoaded();
      },
      (err) => {
        handleFirestoreError(err, OperationType.GET, 'schedules');
        notifyInitialLoaded();
      }
    );
    unsubscribers.push(unsub);
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, 'schedules');
    notifyInitialLoaded();
  }

  // 8. Attendance Records (Real-time 2-way sync across all devices: QR, Admin, Token)
  try {
    let hasMergedInitialOfflineAttendance = false;
    const unsub = onSnapshot(
      collection(db, 'attendance_records'),
      (snap) => {
        const cloudDocs = snap.docs.map((d) => d.data() as AttendanceRecord);
        // Valid records must have nipd, tanggal, status across ANY dates
        const validCloudRecords = cloudDocs.filter(
          (r) => r && r.nipd && r.tanggal && r.status
        );

        let currentRecords = validCloudRecords;

        // If cloud already has records, cloud is the authoritative source of truth across all devices!
        // Only if cloud was completely empty (fresh project) do we initialize cloud from local fallbacks.
        if (!hasMergedInitialOfflineAttendance) {
          hasMergedInitialOfflineAttendance = true;
          const validOfflineLocal = (initialFallbacks.attendance || []).filter(
            (lr) => lr && lr.nipd && lr.tanggal && lr.status
          );

          if (validOfflineLocal.length > 0 && validCloudRecords.length === 0) {
            // Cloud was completely empty, upload initial valid records
            firestoreSaveAttendanceRecordsBatch(validOfflineLocal);
            currentRecords = validOfflineLocal;
          }
        }

        // Deduplicate deterministic doc IDs with trimmed keys
        const map = new Map<string, AttendanceRecord>();
        currentRecords.forEach((r) => {
          if (r && r.nipd && r.tanggal) {
            const key = `${r.nipd.trim()}_${r.tanggal.trim()}`;
            map.set(key, r);
          }
        });
        const finalAttendance = Array.from(map.values());

        callbacks.onAttendanceLoaded?.(finalAttendance);
        saveAttendanceRecords(finalAttendance);
        notifyInitialLoaded();
      },
      (err) => {
        handleFirestoreError(err, OperationType.GET, 'attendance_records');
        notifyInitialLoaded();
      }
    );
    unsubscribers.push(unsub);
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, 'attendance_records');
    notifyInitialLoaded();
  }

  // 9. Tokens
  try {
    const unsub = onSnapshot(
      collection(db, 'tokens'),
      (snap) => {
        if (snap.empty && initialFallbacks.tokens && initialFallbacks.tokens.length > 0) {
          firestoreSaveBatchChunked('tokens', initialFallbacks.tokens, (t) => t.id);
          callbacks.onTokensLoaded?.(initialFallbacks.tokens);
          saveTokens(initialFallbacks.tokens);
        } else {
          const items = snap.docs.map((d) => d.data() as AttendanceToken);
          callbacks.onTokensLoaded?.(items);
          saveTokens(items);
        }
        notifyInitialLoaded();
      },
      (err) => {
        handleFirestoreError(err, OperationType.GET, 'tokens');
        notifyInitialLoaded();
      }
    );
    unsubscribers.push(unsub);
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, 'tokens');
    notifyInitialLoaded();
  }

  // 10. Teacher Attendance Records
  try {
    let hasMergedInitialTeacherAttendance = false;
    const unsub = onSnapshot(
      collection(db, 'teacher_attendance_records'),
      (snap) => {
        if (snap.empty && initialFallbacks.teacherAttendance && initialFallbacks.teacherAttendance.length > 0) {
          firestoreSaveBatchChunked('teacher_attendance_records', initialFallbacks.teacherAttendance, (t) => t.id);
          callbacks.onTeacherAttendanceLoaded?.(initialFallbacks.teacherAttendance);
          saveTeacherAttendanceRecords(initialFallbacks.teacherAttendance);
        } else {
          const items = snap.docs.map((d) => d.data() as TeacherAttendanceRecord);
          let finalTeacherAttendance = items;
          if (!hasMergedInitialTeacherAttendance && initialFallbacks.teacherAttendance && initialFallbacks.teacherAttendance.length > 0) {
            hasMergedInitialTeacherAttendance = true;
            const missingInCloud = initialFallbacks.teacherAttendance.filter(
              (lt) => lt && lt.id && !items.some((ct) => ct.id === lt.id || (ct.teacherId === lt.teacherId && ct.tanggal === lt.tanggal))
            );
            if (missingInCloud.length > 0) {
              firestoreSaveBatchChunked('teacher_attendance_records', missingInCloud, (t) => t.id);
              finalTeacherAttendance = [...items, ...missingInCloud];
            }
          }
          callbacks.onTeacherAttendanceLoaded?.(finalTeacherAttendance);
          saveTeacherAttendanceRecords(finalTeacherAttendance);
        }
        notifyInitialLoaded();
      },
      (err) => {
        handleFirestoreError(err, OperationType.GET, 'teacher_attendance_records');
        notifyInitialLoaded();
      }
    );
    unsubscribers.push(unsub);
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, 'teacher_attendance_records');
    notifyInitialLoaded();
  }

  // Safety fallback: unblock UI within 1.5 seconds if network latency occurs
  const fallbackTimer = setTimeout(() => {
    callbacks.onInitialSyncComplete?.();
  }, 1500);

  return () => {
    clearTimeout(fallbackTimer);
    unsubscribers.forEach((fn) => fn());
  };
}

// =========================================================================
// MUTATION HELPERS: Directly save/delete in Firestore (persists across devices)
// =========================================================================

export async function firestoreSaveStudent(student: Student) {
  try {
    const cleaned = cleanForFirestore(student);
    await setDoc(doc(db, 'students', sanitizeDocId(student.nipd)), cleaned, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `students/${student.nipd}`);
  }
}

export async function firestoreDeleteStudent(nipd: string) {
  try {
    await deleteDoc(doc(db, 'students', sanitizeDocId(nipd)));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `students/${nipd}`);
  }
}

export async function firestoreSaveRombel(rombel: Rombel) {
  try {
    const cleaned = cleanForFirestore(rombel);
    await setDoc(doc(db, 'rombels', sanitizeDocId(rombel.id)), cleaned, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `rombels/${rombel.id}`);
  }
}

export async function firestoreDeleteRombel(rombelId: string) {
  try {
    await deleteDoc(doc(db, 'rombels', sanitizeDocId(rombelId)));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `rombels/${rombelId}`);
  }
}

export async function firestoreSaveUser(user: UserAccount) {
  try {
    const cleaned = cleanForFirestore(user);
    await setDoc(doc(db, 'users', sanitizeDocId(user.id)), cleaned, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `users/${user.id}`);
  }
}

export async function firestoreDeleteUser(userId: string) {
  try {
    await deleteDoc(doc(db, 'users', sanitizeDocId(userId)));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `users/${userId}`);
  }
}

export async function firestoreSaveTeacher(teacher: Teacher) {
  try {
    const cleaned = cleanForFirestore(teacher);
    await setDoc(doc(db, 'teachers', sanitizeDocId(teacher.id)), cleaned, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `teachers/${teacher.id}`);
  }
}

export async function firestoreDeleteTeacher(teacherId: string) {
  try {
    await deleteDoc(doc(db, 'teachers', sanitizeDocId(teacherId)));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `teachers/${teacherId}`);
  }
}

export async function firestoreSaveSubject(subject: Subject) {
  try {
    const cleaned = cleanForFirestore(subject);
    await setDoc(doc(db, 'subjects', sanitizeDocId(subject.id)), cleaned, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `subjects/${subject.id}`);
  }
}

export async function firestoreDeleteSubject(subjectId: string) {
  try {
    await deleteDoc(doc(db, 'subjects', sanitizeDocId(subjectId)));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `subjects/${subjectId}`);
  }
}

export async function firestoreSaveSchedule(schedule: ScheduleItem) {
  try {
    const cleaned = cleanForFirestore(schedule);
    await setDoc(doc(db, 'schedules', sanitizeDocId(schedule.id)), cleaned, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `schedules/${schedule.id}`);
  }
}

export async function firestoreDeleteSchedule(scheduleId: string) {
  try {
    await deleteDoc(doc(db, 'schedules', sanitizeDocId(scheduleId)));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `schedules/${scheduleId}`);
  }
}

export async function firestoreSaveAttendanceRecord(record: AttendanceRecord) {
  try {
    const docId = record.id || `ATT_${record.tanggal}_${(record.nipd || '').trim().replace(/[^a-zA-Z0-9]/g, '_')}`;
    const cleaned = cleanForFirestore({ ...record, id: docId });
    await setDoc(doc(db, 'attendance_records', sanitizeDocId(docId)), cleaned, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `attendance_records/${record?.id}`);
  }
}

export async function firestoreSaveAttendanceRecordsBatch(records: AttendanceRecord[]) {
  if (!records || records.length === 0) return;
  const CHUNK_SIZE = 400;
  for (let i = 0; i < records.length; i += CHUNK_SIZE) {
    const chunk = records.slice(i, i + CHUNK_SIZE);
    const batch = writeBatch(db);
    chunk.forEach((r) => {
      const docId = r.id || `ATT_${r.tanggal}_${(r.nipd || '').trim().replace(/[^a-zA-Z0-9]/g, '_')}`;
      const cleaned = cleanForFirestore({ ...r, id: docId });
      batch.set(doc(db, 'attendance_records', sanitizeDocId(docId)), cleaned, { merge: true });
    });
    try {
      await batch.commit();
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'attendance_records');
    }
  }
}

export async function firestoreDeleteAttendanceRecord(recordId: string) {
  try {
    await deleteDoc(doc(db, 'attendance_records', sanitizeDocId(recordId)));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `attendance_records/${recordId}`);
  }
}

export async function firestoreDeleteAttendanceRecordsBatch(recordIds: string[]) {
  if (!recordIds || recordIds.length === 0) return;
  const CHUNK_SIZE = 400;
  for (let i = 0; i < recordIds.length; i += CHUNK_SIZE) {
    const chunk = recordIds.slice(i, i + CHUNK_SIZE);
    const batch = writeBatch(db);
    chunk.forEach((id) => {
      batch.delete(doc(db, 'attendance_records', sanitizeDocId(id)));
    });
    try {
      await batch.commit();
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, 'attendance_records_batch');
    }
  }
}

export async function firestoreSaveToken(token: AttendanceToken) {
  try {
    const cleaned = cleanForFirestore(token);
    await setDoc(doc(db, 'tokens', sanitizeDocId(token.id)), cleaned, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `tokens/${token.id}`);
  }
}

export async function firestoreDeleteToken(tokenId: string) {
  try {
    await deleteDoc(doc(db, 'tokens', sanitizeDocId(tokenId)));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `tokens/${tokenId}`);
  }
}

export async function firestoreSaveSchoolConfig(config: SchoolConfig) {
  try {
    const cleaned = cleanForFirestore(config);
    await setDoc(doc(db, 'school_config', 'main'), cleaned, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, 'school_config/main');
  }
}

export async function firestoreSaveUsersBatch(users: UserAccount[]): Promise<void> {
  return firestoreSaveBatchChunked('users', users, (u) => u.id);
}

export async function firestoreSaveStudentsBatch(students: Student[]): Promise<void> {
  return firestoreSaveBatchChunked('students', students, (s) => s.nipd);
}

export async function firestoreSaveTeachersBatch(teachers: Teacher[]): Promise<void> {
  return firestoreSaveBatchChunked('teachers', teachers, (t) => t.id);
}

export async function firestoreSaveSubjectsBatch(subjects: Subject[]): Promise<void> {
  return firestoreSaveBatchChunked('subjects', subjects, (s) => s.id);
}

export async function firestoreSaveSchedulesBatch(schedules: ScheduleItem[]): Promise<void> {
  return firestoreSaveBatchChunked('schedules', schedules, (sc) => sc.id);
}

// Teacher Attendance Mutations
export async function firestoreSaveTeacherAttendance(record: TeacherAttendanceRecord): Promise<void> {
  try {
    const cleaned = cleanForFirestore(record);
    const docId = sanitizeDocId(record.id);
    await setDoc(doc(db, 'teacher_attendance_records', docId), cleaned, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `teacher_attendance_records/${record.id}`);
  }
}

export async function firestoreDeleteTeacherAttendance(recordId: string): Promise<void> {
  try {
    const docId = sanitizeDocId(recordId);
    await deleteDoc(doc(db, 'teacher_attendance_records', docId));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `teacher_attendance_records/${recordId}`);
  }
}

export async function firestoreSaveTeacherAttendanceBatch(records: TeacherAttendanceRecord[]): Promise<void> {
  return firestoreSaveBatchChunked('teacher_attendance_records', records, (r) => r.id);
}

// Reconciles Firestore collection with new list: removes obsolete docs and writes updated items
async function reconcileCollection<T>(
  collectionName: string,
  newItems: T[],
  getId: (item: T) => string
): Promise<void> {
  try {
    const newIds = new Set(newItems.map((item) => sanitizeDocId(getId(item))));
    const snap = await getDocs(collection(db, collectionName));
    const toDelete: string[] = [];
    snap.docs.forEach((d) => {
      if (!newIds.has(d.id)) {
        toDelete.push(d.id);
      }
    });
    for (const docId of toDelete) {
      await deleteDoc(doc(db, collectionName, docId)).catch(() => {});
    }
  } catch (err) {
    console.warn(`[Reconcile ${collectionName}] Warning:`, err);
  }
  await firestoreSaveBatchChunked(collectionName, newItems, getId);
}

// Restore entire system backup data directly to Firebase Firestore
export async function firestoreRestoreFullBackup(payload: FullBackupPayload): Promise<boolean> {
  try {
    // 1. School config
    if (payload.schoolConfig) {
      await firestoreSaveSchoolConfig(payload.schoolConfig);
    }
    // 2. Rombels
    if (payload.rombels && payload.rombels.length > 0) {
      await reconcileCollection('rombels', payload.rombels, (r) => r.id);
    }
    // 3. Students
    if (payload.students && payload.students.length > 0) {
      await reconcileCollection('students', payload.students, (s) => s.nipd);
    }
    // 4. Users
    if (payload.users && payload.users.length > 0) {
      await reconcileCollection('users', payload.users, (u) => u.id);
    }
    // 5. Teachers
    if (payload.teachers && payload.teachers.length > 0) {
      await reconcileCollection('teachers', payload.teachers, (t) => t.id);
    }
    // 6. Subjects
    if (payload.subjects && payload.subjects.length > 0) {
      await reconcileCollection('subjects', payload.subjects, (s) => s.id);
    }
    // 7. Schedules
    if (payload.schedules && payload.schedules.length > 0) {
      await reconcileCollection('schedules', payload.schedules, (sc) => sc.id);
    }
    // 8. Attendance Records
    if (payload.attendanceRecords && payload.attendanceRecords.length > 0) {
      await reconcileCollection('attendance_records', payload.attendanceRecords, (ar) => ar.id);
    }
    // 9. Tokens
    if (payload.tokens && payload.tokens.length > 0) {
      await reconcileCollection('tokens', payload.tokens, (tk) => tk.id);
    }
    // 10. Teacher Attendance Records
    if (payload.teacherAttendanceRecords && payload.teacherAttendanceRecords.length > 0) {
      await reconcileCollection('teacher_attendance_records', payload.teacherAttendanceRecords, (tr) => tr.id);
    }
    return true;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, 'restore_full_backup');
    return false;
  }
}

// Manually trigger a fresh full fetch from Firebase Firestore across all collections
// Bypasses any stale cache and guarantees complete sync across mobile and PC
export async function forceSyncAllFromCloud(
  callbacks: FirestoreDataCallbacks
): Promise<{
  success: boolean;
  studentsCount: number;
  rombelsCount: number;
  usersCount: number;
  teachersCount: number;
  attendanceCount: number;
  teacherAttendanceCount: number;
  schedulesCount: number;
  subjectsCount: number;
  error?: string;
}> {
  try {
    const [
      studentsSnap,
      rombelsSnap,
      usersSnap,
      teachersSnap,
      subjectsSnap,
      schedulesSnap,
      attendanceSnap,
      tokensSnap,
      teacherAttendanceSnap,
    ] = await Promise.all([
      getDocs(collection(db, 'students')),
      getDocs(collection(db, 'rombels')),
      getDocs(collection(db, 'users')),
      getDocs(collection(db, 'teachers')),
      getDocs(collection(db, 'subjects')),
      getDocs(collection(db, 'schedules')),
      getDocs(collection(db, 'attendance_records')),
      getDocs(collection(db, 'tokens')),
      getDocs(collection(db, 'teacher_attendance_records')),
    ]);

    // Parse and update each
    const students = studentsSnap.docs.map((d) => d.data() as Student);
    if (students.length > 0) {
      callbacks.onStudentsLoaded?.(students);
      saveStudentList(students);
    }

    const rombels = rombelsSnap.docs.map((d) => d.data() as Rombel);
    if (rombels.length > 0) {
      callbacks.onRombelsLoaded?.(rombels);
      saveRombelList(rombels);
    }

    const users = usersSnap.docs.map((d) => d.data() as UserAccount);
    if (users.length > 0) {
      callbacks.onUsersLoaded?.(users);
      saveUserList(users);
    }

    const teachers = teachersSnap.docs.map((d) => d.data() as Teacher);
    if (teachers.length > 0) {
      callbacks.onTeachersLoaded?.(teachers);
      saveTeacherList(teachers);
    }

    const subjects = subjectsSnap.docs.map((d) => d.data() as Subject);
    if (subjects.length > 0) {
      callbacks.onSubjectsLoaded?.(subjects);
      saveSubjectList(subjects);
    }

    const schedules = schedulesSnap.docs.map((d) => d.data() as ScheduleItem);
    if (schedules.length > 0) {
      callbacks.onSchedulesLoaded?.(schedules);
      saveScheduleList(schedules);
    }

    const rawAttendance = attendanceSnap.docs.map((d) => d.data() as AttendanceRecord);
    const validAttendance = rawAttendance.filter((r) => r && r.nipd && r.tanggal && r.status);
    // Deduplicate
    const attMap = new Map<string, AttendanceRecord>();
    validAttendance.forEach((r) => attMap.set(`${r.nipd.trim()}_${r.tanggal.trim()}`, r));

    // Cloud is the master source of truth: sync the exact attendance state from cloud
    const attendance = Array.from(attMap.values());
    callbacks.onAttendanceLoaded?.(attendance);
    saveAttendanceRecords(attendance);

    const tokens = tokensSnap.docs.map((d) => d.data() as AttendanceToken);
    if (tokens.length > 0) {
      callbacks.onTokensLoaded?.(tokens);
      saveTokens(tokens);
    }

    const teacherAttendance = teacherAttendanceSnap.docs.map((d) => d.data() as TeacherAttendanceRecord);
    callbacks.onTeacherAttendanceLoaded?.(teacherAttendance);
    saveTeacherAttendanceRecords(teacherAttendance);

    return {
      success: true,
      studentsCount: students.length,
      rombelsCount: rombels.length,
      usersCount: users.length,
      teachersCount: teachers.length,
      attendanceCount: attendance.length,
      teacherAttendanceCount: teacherAttendance.length,
      schedulesCount: schedules.length,
      subjectsCount: subjects.length,
    };
  } catch (err) {
    const errInfo = handleFirestoreError(err, OperationType.GET, 'force_sync_all');
    return {
      success: false,
      studentsCount: 0,
      rombelsCount: 0,
      usersCount: 0,
      teachersCount: 0,
      attendanceCount: 0,
      teacherAttendanceCount: 0,
      schedulesCount: 0,
      subjectsCount: 0,
      error: errInfo.error,
    };
  }
}

