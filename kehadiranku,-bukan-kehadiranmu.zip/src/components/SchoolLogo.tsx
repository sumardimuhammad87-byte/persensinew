import React, { useState } from 'react';
import { DEFAULT_SCHOOL_LOGO_DATA_URI } from '../data/initialData';

interface SchoolLogoProps {
  logoUrl?: string;
  className?: string;
  alt?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
}

export { DEFAULT_SCHOOL_LOGO_DATA_URI };

export const SchoolLogo: React.FC<SchoolLogoProps> = ({
  logoUrl,
  className = 'w-10 h-10',
  alt = 'Logo SMK Bakti Putra Mandiri',
}) => {
  const [hasError, setHasError] = useState(false);

  // If no URL or known broken unsplash URL or failed to load, render resilient vector emblem
  const isBrokenUnsplash =
    logoUrl &&
    logoUrl.includes('images.unsplash.com') &&
    (logoUrl.includes('photo-1546410531') || logoUrl.includes('photo-1580582932707'));

  const shouldUseImage = Boolean(logoUrl) && !hasError && !isBrokenUnsplash;

  if (shouldUseImage && logoUrl) {
    return (
      <img
        src={logoUrl}
        alt={alt}
        className={`object-contain select-none shrink-0 ${className}`}
        onError={() => setHasError(true)}
        loading="eager"
      />
    );
  }

  // Guaranteed inline SVG emblem that never fails to render on any device/browser
  return (
    <svg
      viewBox="0 0 200 200"
      className={`select-none shrink-0 ${className}`}
      aria-label={alt}
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <linearGradient id="shieldGradInline" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#059669" />
          <stop offset="100%" stopColor="#022c22" />
        </linearGradient>
        <linearGradient id="goldGradInline" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#fef08a" />
          <stop offset="50%" stopColor="#f59e0b" />
          <stop offset="100%" stopColor="#b45309" />
        </linearGradient>
        <filter id="shadowInline" x="-10%" y="-10%" width="120%" height="120%">
          <feDropShadow dx="0" dy="3" stdDeviation="2" floodOpacity="0.35" />
        </filter>
      </defs>
      {/* Outer Golden Shield */}
      <path
        d="M100 12 L175 42 C175 125 100 184 100 184 C100 184 25 125 25 42 Z"
        fill="url(#goldGradInline)"
        filter="url(#shadowInline)"
      />
      {/* Inner Emerald Shield */}
      <path
        d="M100 22 L165 48 C165 120 100 172 100 172 C100 172 35 120 35 48 Z"
        fill="url(#shieldGradInline)"
        stroke="#10b981"
        strokeWidth="2"
      />
      {/* Golden Morarboard / Top Crown */}
      <polygon points="100,50 144,66 100,82 56,66" fill="url(#goldGradInline)" />
      <polygon points="100,82 134,71 134,86 100,96 66,86 66,71" fill="#b45309" />
      {/* Tassel */}
      <path d="M60 68 L52 82 L52 102" stroke="#fbbf24" strokeWidth="3" fill="none" strokeLinecap="round" />
      <circle cx="52" cy="105" r="4.5" fill="#f59e0b" />
      {/* Open Book Pages */}
      <path
        d="M100 110 C116 100 138 102 150 110 L150 140 C138 132 116 130 100 140 Z"
        fill="#ffffff"
        filter="url(#shadowInline)"
      />
      <path
        d="M100 110 C84 100 62 102 50 110 L50 140 C62 132 84 130 100 140 Z"
        fill="#e2e8f0"
        filter="url(#shadowInline)"
      />
      <line x1="100" y1="110" x2="100" y2="140" stroke="#047857" strokeWidth="2" />
      {/* Star / Emblem at base */}
      <polygon
        points="100,148 103,155 110,155 104,159 106,166 100,162 94,166 96,159 90,155 97,155"
        fill="url(#goldGradInline)"
      />
    </svg>
  );
};

