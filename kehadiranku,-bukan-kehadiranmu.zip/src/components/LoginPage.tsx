import React, { useState, useMemo } from 'react';
import { UserAccount, SchoolConfig, Student, Rombel } from '../types';
import { SchoolLogo } from './SchoolLogo';
import {
  Lock,
  User,
  Eye,
  EyeOff,
  AlertCircle,
  ArrowRight,
  Shield,
  QrCode,
  Sparkles,
  Zap,
  FileCode,
  Database,
  Search,
  Check,
  ChevronRight,
  X,
  Users,
  BookOpen,
} from 'lucide-react';

interface LoginPageProps {
  users: UserAccount[];
  students?: Student[];
  rombels?: Rombel[];
  schoolConfig: SchoolConfig;
  onLoginSuccess: (user: UserAccount) => void;
  onAutoCreateUser?: (user: UserAccount) => void;
  onOpenArchDocs?: () => void;
  onOpenBackupModal?: () => void;
}

// Helper: Normalize text for robust Indonesian name & ID matching (handles curly quotes, dashes, dots)
function normalizeForSearch(str: string = ''): string {
  return str
    .toLowerCase()
    .replace(/[\u2018\u2019\u02BC`']/g, '') // strip all variations of apostrophes/quotes
    .replace(/[-_.]/g, ' ') // convert dashes, dots, underscores to spaces
    .replace(/\s+/g, ' ')
    .trim();
}

function normalizeAlphaNum(str: string = ''): string {
  return str.toLowerCase().replace(/[^a-z0-9]/g, '');
}

function normalizeDigits(str: string = ''): string {
  return str.replace(/\D/g, '');
}

export const LoginPage: React.FC<LoginPageProps> = ({
  users,
  students = [],
  rombels = [],
  schoolConfig,
  onLoginSuccess,
  onAutoCreateUser,
  onOpenArchDocs,
  onOpenBackupModal,
}) => {
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Student Directory & Search State
  const [isStudentSearchOpen, setIsStudentSearchOpen] = useState(false);
  const [studentSearchQuery, setStudentSearchQuery] = useState('');
  const [selectedRombelFilter, setSelectedRombelFilter] = useState<string>('ALL');

  // Candidate matches when typed name matches multiple students
  const [candidateMatches, setCandidateMatches] = useState<Student[]>([]);

  // Map rombelId to name
  const rombelMap = useMemo(() => {
    const map: Record<string, string> = {};
    rombels.forEach((r) => {
      map[r.id] = r.nama;
    });
    return map;
  }, [rombels]);

  // Filtered student list for student directory
  const directoryStudents = useMemo(() => {
    if (students.length === 0) return [];
    let list = students;

    if (selectedRombelFilter !== 'ALL') {
      list = list.filter((s) => s.rombelId === selectedRombelFilter);
    }

    if (studentSearchQuery.trim()) {
      const qNorm = normalizeForSearch(studentSearchQuery);
      const qAlpha = normalizeAlphaNum(studentSearchQuery);
      const qDigits = normalizeDigits(studentSearchQuery);

      list = list.filter((s) => {
        const sNamaNorm = normalizeForSearch(s.nama);
        const sNipdAlpha = normalizeAlphaNum(s.nipd);
        const sNisnDigits = normalizeDigits(s.nisn || '');

        const matchesName = sNamaNorm.includes(qNorm);
        const matchesNipd = sNipdAlpha.includes(qAlpha);
        const matchesNisn = qDigits.length >= 3 && sNisnDigits.includes(qDigits);

        return matchesName || matchesNipd || matchesNisn;
      });
    }

    return list;
  }, [students, selectedRombelFilter, studentSearchQuery]);

  // Main login executor
  const submitLogin = (idInput: string, passInput: string, explicitStudent?: Student) => {
    const rawId = idInput.trim();
    const cleanId = rawId.toLowerCase();
    const cleanPass = passInput.trim();

    if (!cleanId && !explicitStudent) {
      setErrorMessage('Silakan masukkan NISN, NIPD, Email, atau Nama Siswa Anda.');
      return;
    }

    setIsLoading(true);
    setErrorMessage(null);
    setCandidateMatches([]);

    setTimeout(() => {
      const cleanNorm = normalizeForSearch(cleanId);
      const cleanAlpha = normalizeAlphaNum(cleanId);
      const cleanDigits = normalizeDigits(cleanId);

      // Step A: Determine matched student (if identifier corresponds to a student)
      let matchedStudent: Student | null = explicitStudent || null;

      if (!matchedStudent && students.length > 0) {
        // Find all student candidates
        const candidates = students.filter((s) => {
          const sNipd = s.nipd.trim();
          const sNipdAlpha = normalizeAlphaNum(sNipd);
          const sNisnDigits = normalizeDigits(s.nisn || '');
          const sNamaNorm = normalizeForSearch(s.nama);

          // 1. Exact or AlphaNum NIPD match (e.g. 24.25.10.001 or 242510001)
          if (
            sNipd.toLowerCase() === cleanId ||
            (cleanAlpha.length >= 4 && sNipdAlpha === cleanAlpha)
          ) {
            return true;
          }

          // 2. NISN match (exact or numeric digits, e.g. 0094701443 or 94701443)
          if (sNisnDigits && cleanDigits.length >= 4) {
            if (
              sNisnDigits === cleanDigits ||
              sNisnDigits.endsWith(cleanDigits) ||
              cleanDigits.endsWith(sNisnDigits)
            ) {
              return true;
            }
          }

          // 3. Exact full name match
          if (sNamaNorm === cleanNorm) {
            return true;
          }

          // 4. Substring name match
          if (sNamaNorm.includes(cleanNorm) || (cleanNorm.length >= 4 && cleanNorm.includes(sNamaNorm))) {
            return true;
          }

          // 5. Word-level match (e.g. "ainun" or "putri utami")
          const queryWords = cleanNorm.split(' ').filter((w) => w.length >= 2);
          if (queryWords.length > 0 && queryWords.every((w) => sNamaNorm.includes(w))) {
            return true;
          }

          return false;
        });

        // If multiple students match the typed name (e.g. "Dinda", "Putri", "Alin"), prompt the user to choose
        if (candidates.length > 1) {
          setIsLoading(false);
          setCandidateMatches(candidates);
          setErrorMessage(null);
          return;
        }

        if (candidates.length === 1) {
          matchedStudent = candidates[0];
        }
      }

      // Step B: Match or Create UserAccount
      let matchedUser: UserAccount | null = null;

      // If matchedStudent is identified, lookup their user by NIPD or NISN
      if (matchedStudent) {
        const sNipdClean = matchedStudent.nipd.trim().toLowerCase();
        const sNipdAlpha = normalizeAlphaNum(matchedStudent.nipd);
        const sNisnDigits = normalizeDigits(matchedStudent.nisn || '');

        matchedUser =
          users.find((u) => {
            const uNipd = (u.nipd || '').trim().toLowerCase();
            const uNipdAlpha = normalizeAlphaNum(u.nipd || '');
            const uNisnDigits = normalizeDigits(u.nisn || '');
            const uUsernameAlpha = normalizeAlphaNum(u.username || '');

            return (
              (uNipd && uNipd === sNipdClean) ||
              (uNipdAlpha && uNipdAlpha === sNipdAlpha) ||
              (uUsernameAlpha && uUsernameAlpha === sNipdAlpha) ||
              (sNisnDigits && uNisnDigits && sNisnDigits === uNisnDigits)
            );
          }) || null;

        // If student exists in roster but user account hasn't been created yet, create it on-the-fly
        if (!matchedUser) {
          const newAccountId = `USR-STD-${matchedStudent.nipd.replace(/[^a-zA-Z0-9]/g, '')}`;
          const newAccount: UserAccount = {
            id: newAccountId,
            email: `${matchedStudent.nipd.replace(/[^a-zA-Z0-9]/g, '')}@siswa.sch.id`,
            username: matchedStudent.nipd,
            nama: matchedStudent.nama,
            role: 'siswa',
            password: '123',
            nipd: matchedStudent.nipd,
            nisn: matchedStudent.nisn,
            rombelId: matchedStudent.rombelId,
            jabatan: 'Siswa',
            foto: matchedStudent.foto,
            statusAktif: matchedStudent.statusAktif !== false,
          };
          matchedUser = newAccount;
          onAutoCreateUser?.(newAccount);
        }
      }

      // If still no user matched, search through all user accounts (for Admin, Guru, Walas, Staf)
      if (!matchedUser) {
        matchedUser =
          users.find((u) => {
            const matchesEmail = u.email && u.email.toLowerCase().trim() === cleanId;
            const matchesUsername = u.username && u.username.toLowerCase().trim() === cleanId;
            const matchesUsernameAlpha =
              u.username && normalizeAlphaNum(u.username) === cleanAlpha;
            const matchesNipd = u.nipd && u.nipd.toLowerCase().trim() === cleanId;
            const matchesNipdAlpha = u.nipd && normalizeAlphaNum(u.nipd) === cleanAlpha;
            const matchesNisn =
              u.nisn &&
              (u.nisn.toLowerCase().trim() === cleanId ||
                (cleanDigits.length >= 4 && normalizeDigits(u.nisn) === cleanDigits));
            const matchesNamaNorm =
              u.nama && normalizeForSearch(u.nama).includes(cleanNorm);

            return (
              matchesEmail ||
              matchesUsername ||
              matchesUsernameAlpha ||
              matchesNipd ||
              matchesNipdAlpha ||
              matchesNisn ||
              matchesNamaNorm
            );
          }) || null;
      }

      if (!matchedUser) {
        setIsLoading(false);
        setErrorMessage(
          'Akun tidak ditemukan. Masukkan NISN, NIPD, Username, atau gunakan tombol "Cari & Pilih Nama Siswa" di bawah.'
        );
        return;
      }

      // Check active status
      if (matchedUser.statusAktif === false) {
        setIsLoading(false);
        setErrorMessage('Akun Anda dinonaktifkan. Silakan hubungi Administrator Sistem.');
        return;
      }

      // Step C: Flexible Password / PIN Verification
      const userPassword = matchedUser.password || '123';
      let isStudentPassword = false;

      const isStudentAccount =
        matchedUser.role === 'siswa' ||
        matchedUser.role === 'ketua_kelas' ||
        matchedUser.role === 'sekretaris' ||
        Boolean(matchedUser.nipd) ||
        Boolean(matchedStudent);

      if (isStudentAccount) {
        const studentNisn = matchedStudent?.nisn || matchedUser.nisn || '';
        const studentNipd = matchedStudent?.nipd || matchedUser.nipd || '';
        const birthDateRaw = matchedStudent?.tanggalLahir || '';
        const birthDateDigits = normalizeDigits(birthDateRaw);
        const birthDateReversed = birthDateRaw.includes('-')
          ? birthDateRaw.split('-').reverse().join('')
          : '';

        isStudentPassword =
          !cleanPass || // Blank/empty password allowed for student ease
          cleanPass === '123' ||
          cleanPass === '123456' ||
          (Boolean(studentNisn) &&
            (cleanPass === studentNisn || normalizeDigits(cleanPass) === normalizeDigits(studentNisn))) ||
          (Boolean(studentNipd) &&
            (cleanPass === studentNipd || normalizeAlphaNum(cleanPass) === normalizeAlphaNum(studentNipd))) ||
          (Boolean(birthDateDigits) && cleanPass === birthDateDigits) ||
          (Boolean(birthDateReversed) && cleanPass === birthDateReversed);
      }

      const isPasswordValid =
        cleanPass === userPassword ||
        isStudentPassword ||
        (matchedUser.role === 'admin' && (cleanPass === 'admin123' || cleanPass === 'admin')) ||
        ((matchedUser.role === 'guru' || matchedUser.role === 'walas' || matchedUser.role === 'staf') &&
          (cleanPass === '123456' ||
            cleanPass === 'walas123' ||
            cleanPass === 'guru123' ||
            cleanPass === 'staf123' ||
            cleanPass === '123'));

      if (!isPasswordValid) {
        setIsLoading(false);
        setErrorMessage('Kata sandi atau PIN salah. Silakan periksa kembali kredensial Anda.');
        return;
      }

      setIsLoading(false);
      onLoginSuccess(matchedUser);
    }, 250);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    submitLogin(identifier, password);
  };

  const handleSelectSearchedStudent = (student: Student) => {
    setIdentifier(student.nipd);
    setPassword('123');
    setIsStudentSearchOpen(false);
    setCandidateMatches([]);
    setErrorMessage(null);
    submitLogin(student.nipd, '123', student);
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col justify-between relative overflow-hidden font-sans">
      {/* Background Decorative Gradient Orbs */}
      <div className="absolute -top-32 -left-32 w-96 h-96 bg-emerald-600/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-1/2 -right-32 w-96 h-96 bg-indigo-600/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-32 left-1/3 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Top Header Bar */}
      <header className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-white/10 backdrop-blur-md p-1.5 shadow-md border border-white/20 flex items-center justify-center shrink-0">
            <SchoolLogo logoUrl={schoolConfig.logoUrl} className="w-full h-full rounded-xl" />
          </div>
          <div>
            <span className="text-white font-black text-sm sm:text-base tracking-tight block leading-tight">
              {schoolConfig.namaSekolah}
            </span>
            <span className="text-slate-400 text-xs flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              Sistem Presensi Siswa Digital & Cloud Firestore
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {onOpenBackupModal && (
            <button
              id="btn-login-backup-restore"
              onClick={onOpenBackupModal}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-400 hover:text-emerald-300 text-xs font-semibold border border-slate-700 transition cursor-pointer"
              title="Cadangkan atau Pulihkan Data Database JSON"
            >
              <Database className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden sm:inline">Cadangan / Pulihkan</span>
            </button>
          )}

          {onOpenArchDocs && (
            <button
              id="btn-login-arch-docs"
              onClick={onOpenArchDocs}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold border border-slate-700 transition"
            >
              <FileCode className="w-3.5 h-3.5 text-emerald-400" />
              <span>Skema SQL & Arsitektur</span>
            </button>
          )}
        </div>
      </header>

      {/* Main Form Center Area */}
      <main className="relative z-10 flex-1 flex items-center justify-center px-4 sm:px-6 py-6">
        <div className="w-full max-w-4xl grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Left Column: Branding, Mission, & Benefits (Hidden on small mobile) */}
          <div className="lg:col-span-5 text-left space-y-5 hidden lg:block pr-4">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Presensi Multi-Perangkat (HP & PC)</span>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-14 h-14 rounded-2xl bg-white/10 p-2 border border-white/20 shadow-lg shrink-0">
                <SchoolLogo logoUrl={schoolConfig.logoUrl} className="w-full h-full" />
              </div>
              <div>
                <h1 className="text-2xl font-black text-white tracking-tight leading-tight">
                  {schoolConfig.namaSekolah}
                </h1>
                <p className="text-xs text-emerald-400 font-bold">
                  {schoolConfig.kotaKab}, {schoolConfig.provinsi}
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Platform absensi dan jadwal mengajar terintegrasi realtime. Masuk sebagai{' '}
              <strong>Siswa</strong> untuk presensi mandiri & scan QR, atau{' '}
              <strong>Guru / Walas / Admin</strong> untuk kelola absensi kelas.
            </p>

            <div className="space-y-2.5 pt-1">
              <div className="flex items-start gap-2.5 text-xs text-slate-300">
                <div className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 shrink-0 mt-0.5">
                  <QrCode className="w-4 h-4" />
                </div>
                <div>
                  <strong className="text-white block font-bold">Scan QR & Token Kelas</strong>
                  Presensi cepat via kamera atau 6-digit token aktif.
                </div>
              </div>

              <div className="flex items-start gap-2.5 text-xs text-slate-300">
                <div className="p-1.5 rounded-lg bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 shrink-0 mt-0.5">
                  <Zap className="w-4 h-4" />
                </div>
                <div>
                  <strong className="text-white block font-bold">Sinkronisasi Cloud Otomatis</strong>
                  Data yang diinput dari HP langsung sinkron ke PC dan sebaliknya.
                </div>
              </div>

              <div className="flex items-start gap-2.5 text-xs text-slate-300">
                <div className="p-1.5 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/30 shrink-0 mt-0.5">
                  <Shield className="w-4 h-4" />
                </div>
                <div>
                  <strong className="text-white block font-bold">Hak Akses Ketat (RBAC)</strong>
                  Akses tersaring sesuai wewenang rombel masing-masing.
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Interactive Login Card */}
          <div className="lg:col-span-7">
            <div className="bg-slate-900/95 backdrop-blur-md rounded-3xl border border-slate-800 p-6 sm:p-7 shadow-2xl space-y-5">
              {/* Header inside Card */}
              <div className="flex items-center justify-between gap-3 border-b border-slate-800 pb-4">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-2xl bg-white/10 p-1.5 border border-white/20 flex items-center justify-center shrink-0">
                    <SchoolLogo logoUrl={schoolConfig.logoUrl} className="w-full h-full" />
                  </div>
                  <div>
                    <h2 className="text-lg sm:text-xl font-black text-white tracking-tight">
                      Masuk ke Sistem
                    </h2>
                    <p className="text-[11px] text-slate-400">
                      Siswa: masukkan NISN, NIPD, atau Nama Lengkap Anda
                    </p>
                  </div>
                </div>

                <div className="text-right hidden sm:block">
                  <span className="text-[11px] font-bold text-emerald-400 flex items-center gap-1.5 justify-end">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                    Cloud Aktif
                  </span>
                  <span className="text-[10px] text-slate-500 block">SMK Bakti Putra Mandiri</span>
                </div>
              </div>

              {/* Error Notice */}
              {errorMessage && (
                <div className="p-3 bg-rose-500/15 border border-rose-500/40 rounded-2xl flex items-start gap-2.5 text-xs text-rose-200 animate-in fade-in">
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                  <span className="leading-relaxed">{errorMessage}</span>
                </div>
              )}

              {/* MULTIPLE CANDIDATES DISAMBIGUATION BOX */}
              {candidateMatches.length > 0 && (
                <div className="p-4 bg-emerald-950/80 border border-emerald-500/50 rounded-2xl space-y-3 animate-in fade-in">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-xs font-bold text-emerald-300">
                      <Users className="w-4 h-4 text-emerald-400" />
                      <span>
                        Ditemukan {candidateMatches.length} Siswa dengan nama tersebut. Klik nama Anda untuk langsung masuk:
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setCandidateMatches([])}
                      className="text-slate-400 hover:text-white text-xs p-1"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="grid grid-cols-1 gap-2 max-h-48 overflow-y-auto pr-1">
                    {candidateMatches.map((cand) => {
                      const rombelName = rombelMap[cand.rombelId] || cand.rombelId;
                      return (
                        <div
                          key={cand.nipd}
                          onClick={() => handleSelectSearchedStudent(cand)}
                          className="p-2.5 bg-slate-900/90 hover:bg-emerald-900/40 border border-slate-700/80 hover:border-emerald-500/80 rounded-xl cursor-pointer flex items-center justify-between transition group"
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-9 h-9 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center overflow-hidden shrink-0">
                              {cand.foto ? (
                                <img src={cand.foto} alt={cand.nama} className="w-full h-full object-cover" />
                              ) : (
                                <User className="w-4 h-4 text-slate-400" />
                              )}
                            </div>
                            <div className="text-left">
                              <strong className="block text-xs font-bold text-white group-hover:text-emerald-300 transition">
                                {cand.nama}
                              </strong>
                              <span className="text-[10px] text-slate-400 block">
                                {rombelName} • NIPD: {cand.nipd}
                              </span>
                            </div>
                          </div>

                          <span className="px-2.5 py-1 rounded-lg bg-emerald-600 group-hover:bg-emerald-500 text-white text-[10px] font-extrabold flex items-center gap-1 shadow-sm shrink-0">
                            <span>Pilih & Masuk</span>
                            <ChevronRight className="w-3 h-3" />
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Student Lookup Tool Toggle */}
              <div>
                <button
                  type="button"
                  onClick={() => setIsStudentSearchOpen(!isStudentSearchOpen)}
                  className="w-full py-2.5 px-3 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 text-xs text-emerald-400 hover:text-emerald-300 font-bold flex items-center justify-between transition cursor-pointer shadow-sm"
                >
                  <div className="flex items-center gap-2">
                    <Search className="w-3.5 h-3.5 text-emerald-400" />
                    <span>
                      {isStudentSearchOpen
                        ? 'Sembunyikan Direktori Siswa'
                        : 'Lupa NIPD/NISN? Klik di sini untuk Cari & Pilih Nama Siswa (1-Klik)'}
                    </span>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950/80 border border-emerald-800 text-emerald-300">
                    {students.length} Siswa
                  </span>
                </button>

                {/* Full Student Directory Modal / Panel */}
                {isStudentSearchOpen && (
                  <div className="mt-3 p-4 bg-slate-950/90 rounded-2xl border border-emerald-500/30 space-y-3 shadow-inner animate-in fade-in">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-bold text-white flex items-center gap-1.5">
                        <BookOpen className="w-3.5 h-3.5 text-emerald-400" />
                        Direktori Lengkap Siswa SMK Bakti Putra Mandiri
                      </span>
                      <button
                        type="button"
                        onClick={() => setIsStudentSearchOpen(false)}
                        className="text-slate-400 hover:text-white text-xs p-1"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    {/* Class Filter Tabs */}
                    <div className="flex flex-wrap gap-1.5">
                      <button
                        type="button"
                        onClick={() => setSelectedRombelFilter('ALL')}
                        className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition cursor-pointer ${
                          selectedRombelFilter === 'ALL'
                            ? 'bg-emerald-600 text-white'
                            : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                        }`}
                      >
                        Semua Kelas ({students.length})
                      </button>
                      {rombels.map((r) => {
                        const countInRombel = students.filter((s) => s.rombelId === r.id).length;
                        return (
                          <button
                            key={r.id}
                            type="button"
                            onClick={() => setSelectedRombelFilter(r.id)}
                            className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition cursor-pointer ${
                              selectedRombelFilter === r.id
                                ? 'bg-emerald-600 text-white'
                                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                            }`}
                          >
                            {r.nama.replace('Kelas ', '')} ({countInRombel})
                          </button>
                        );
                      })}
                    </div>

                    {/* Search Field */}
                    <div className="relative">
                      <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input
                        type="text"
                        placeholder="Ketik nama, NIPD, atau NISN siswa..."
                        value={studentSearchQuery}
                        onChange={(e) => setStudentSearchQuery(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl pl-8 pr-8 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                      />
                      {studentSearchQuery && (
                        <button
                          type="button"
                          onClick={() => setStudentSearchQuery('')}
                          className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      )}
                    </div>

                    {/* Student List */}
                    <div className="max-h-56 overflow-y-auto space-y-1.5 divide-y divide-slate-800/40 pr-1">
                      {directoryStudents.length > 0 ? (
                        directoryStudents.map((s) => {
                          const rombelName = rombelMap[s.rombelId] || s.rombelId;
                          return (
                            <div
                              key={s.nipd}
                              onClick={() => handleSelectSearchedStudent(s)}
                              className="p-2 hover:bg-slate-900 rounded-xl cursor-pointer flex items-center justify-between text-xs text-slate-200 transition group border border-transparent hover:border-emerald-500/40"
                            >
                              <div className="flex items-center gap-2.5">
                                <div className="w-8 h-8 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center overflow-hidden shrink-0">
                                  {s.foto ? (
                                    <img src={s.foto} alt={s.nama} className="w-full h-full object-cover" />
                                  ) : (
                                    <User className="w-3.5 h-3.5 text-slate-400" />
                                  )}
                                </div>
                                <div>
                                  <strong className="block text-white group-hover:text-emerald-400 transition text-[11px] sm:text-xs">
                                    {s.nama}
                                  </strong>
                                  <span className="text-[10px] text-slate-400">
                                    {rombelName} • NIPD: {s.nipd} {s.nisn ? `• NISN: ${s.nisn}` : ''}
                                  </span>
                                </div>
                              </div>
                              <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950 px-2.5 py-1 rounded-lg border border-emerald-800 group-hover:bg-emerald-600 group-hover:text-white transition shrink-0 ml-2">
                                Masuk (1-Klik)
                              </span>
                            </div>
                          );
                        })
                      ) : (
                        <p className="text-[11px] text-slate-500 italic py-2 text-center">
                          Tidak ditemukan siswa yang cocok dengan kata kunci &quot;{studentSearchQuery}&quot;
                        </p>
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* Login Form */}
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1.5">
                    NISN / NIPD / Nama Siswa / Username
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                      <User className="w-4 h-4" />
                    </div>
                    <input
                      id="input-login-identifier"
                      type="text"
                      required
                      placeholder="Ketik Nama, NISN, atau NIPD Anda..."
                      value={identifier}
                      onChange={(e) => {
                        setIdentifier(e.target.value);
                        if (errorMessage) setErrorMessage(null);
                        if (candidateMatches.length > 0) setCandidateMatches([]);
                      }}
                      className="w-full bg-slate-950/80 border border-slate-700 rounded-xl pl-10 pr-3.5 py-2.5 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="block text-xs font-bold text-slate-300">
                      Kata Sandi atau PIN Akun
                    </label>
                  </div>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                      <Lock className="w-4 h-4" />
                    </div>
                    <input
                      id="input-login-password"
                      type={showPassword ? 'text' : 'password'}
                      placeholder="Masukkan Kata Sandi atau PIN Akun..."
                      value={password}
                      onChange={(e) => {
                        setPassword(e.target.value);
                        if (errorMessage) setErrorMessage(null);
                      }}
                      className="w-full bg-slate-950/80 border border-slate-700 rounded-xl pl-10 pr-10 py-2.5 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-200 transition"
                      tabIndex={-1}
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
                  <label className="flex items-center gap-2 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={rememberMe}
                      onChange={(e) => setRememberMe(e.target.checked)}
                      className="rounded bg-slate-950 border-slate-700 text-emerald-600 focus:ring-emerald-500 w-3.5 h-3.5"
                    />
                    <span>Ingat Saya di Perangkat Ini</span>
                  </label>
                </div>

                <button
                  id="btn-submit-login"
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white font-extrabold text-sm shadow-lg hover:shadow-emerald-600/30 transition flex items-center justify-center gap-2 disabled:opacity-60 cursor-pointer"
                >
                  {isLoading ? (
                    <span>Memverifikasi Kredensial...</span>
                  ) : (
                    <>
                      <span>Masuk ke Sistem Presensi</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>

              {/* Security & Multi-device Notice */}
              <div className="pt-2 border-t border-slate-800/80 flex items-center gap-2 text-[11px] text-slate-400">
                <Shield className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>
                  Tersinkronisasi otomatis via Cloud Firestore di seluruh perangkat HP dan Komputer (PC).
                </span>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer info */}
      <footer className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 py-4 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-slate-400 border-t border-slate-800">
        <div>
          © {new Date().getFullYear()} {schoolConfig.namaSekolah}. Hak cipta dilindungi undang-undang.
        </div>
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1">
            <Shield className="w-3.5 h-3.5 text-emerald-400" />
            RBAC Terlindungi
          </span>
          <span>•</span>
          <span>Jam Presensi: {schoolConfig.jamMasuk} - {schoolConfig.jamBatasMasuk} WIB</span>
        </div>
      </footer>
    </div>
  );
};
